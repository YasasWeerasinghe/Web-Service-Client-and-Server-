/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client_Side;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Yasas Weerasingh
 */
@Entity
@Table(name = "message", catalog = "iitcsacw", schema = "")
@NamedQueries({
    @NamedQuery(name = "Message.findAll", query = "SELECT m FROM Message m")
    , @NamedQuery(name = "Message.findByMessage", query = "SELECT m FROM Message m WHERE m.message = :message")
    , @NamedQuery(name = "Message.findByLastEdited", query = "SELECT m FROM Message m WHERE m.lastEdited = :lastEdited")
    , @NamedQuery(name = "Message.findByBy", query = "SELECT m FROM Message m WHERE m.by = :by")})
public class Message implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "message")
    private String message;
    @Id
    @Basic(optional = false)
    @Column(name = "lastEdited")
    private String lastEdited;
    @Basic(optional = false)
    @Column(name = "by")
    private String by;

    public Message() {
    }

    public Message(String lastEdited) {
        this.lastEdited = lastEdited;
    }

    public Message(String lastEdited, String message, String by) {
        this.lastEdited = lastEdited;
        this.message = message;
        this.by = by;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        String oldMessage = this.message;
        this.message = message;
        changeSupport.firePropertyChange("message", oldMessage, message);
    }

    public String getLastEdited() {
        return lastEdited;
    }

    public void setLastEdited(String lastEdited) {
        String oldLastEdited = this.lastEdited;
        this.lastEdited = lastEdited;
        changeSupport.firePropertyChange("lastEdited", oldLastEdited, lastEdited);
    }

    public String getBy() {
        return by;
    }

    public void setBy(String by) {
        String oldBy = this.by;
        this.by = by;
        changeSupport.firePropertyChange("by", oldBy, by);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (lastEdited != null ? lastEdited.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Message)) {
            return false;
        }
        Message other = (Message) object;
        if ((this.lastEdited == null && other.lastEdited != null) || (this.lastEdited != null && !this.lastEdited.equals(other.lastEdited))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Client_Side.Message[ lastEdited=" + lastEdited + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
