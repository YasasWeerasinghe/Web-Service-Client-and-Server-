package Client_Side;

/**
 *
 * @author Yasas Weerasingh
 */
public class Client {

    public static void registration(java.lang.String name, java.lang.String loginID, java.lang.String password, java.lang.String rePassword) {
        sever.Sever_Service service = new sever.Sever_Service();
        sever.Sever port = service.getSeverPort();
        port.registration(name, loginID, password, rePassword);
    }

    public static boolean login(java.lang.String password, java.lang.String loginID) {
        sever.Sever_Service service = new sever.Sever_Service();
        sever.Sever port = service.getSeverPort();
        return port.login(password, loginID);
    }

    public static void chatAddThread(java.lang.String title, java.lang.String createBy, java.lang.String time) {
        severthread.SeverThread_Service service = new severthread.SeverThread_Service();
        severthread.SeverThread port = service.getSeverThreadPort();
        port.chatAddThread(title, createBy, time);
    }

    public static void addMessage(int threadID, java.lang.String message, java.lang.String lastEdited, java.lang.String createBy) {
        severthread.SeverThread_Service service = new severthread.SeverThread_Service();
        severthread.SeverThread port = service.getSeverThreadPort();
        port.addMessage(threadID, message, lastEdited, createBy);
    }

    


    
}
