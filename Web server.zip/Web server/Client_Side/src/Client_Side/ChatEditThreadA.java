package Client_Side;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JFrame;

/**
 *
 * @author Yasas Weerasingh
 */
public class ChatEditThreadA extends javax.swing.JFrame {
 // Initializing the variables
    private int threadId;
    private String id;

    /**
     * Creates new form ChatEditThread
     */
    public ChatEditThreadA() {
        threadId = 0; // 
        initComponents();
    }

    public ChatEditThreadA(int threadId, String ID) {
        this.threadId = threadId;       
        this.id = ID;
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("iitcsacw?zeroDateTimeBehavior=convertToNullPU").createEntityManager();
        messageQuery = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT m FROM Message m");
        messageList = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : messageQuery.getResultList();
        messageQuery1 = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT m FROM Message m");
        messageList1 = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : messageQuery1.getResultList();
        messageQuery2 = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT m FROM Message m");
        messageList2 = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : messageQuery2.getResultList();
        message2Query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT m FROM Message2 m");
        message2List = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : message2Query.getResultList();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        label_LogOut = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        bAdd = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtMessage = new javax.swing.JTextArea();
        bChatSelectWindow = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 162, 0));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Eras Bold ITC", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("DIYO Chat Edit Threads Page");

        label_LogOut.setBackground(new java.awt.Color(255, 255, 255));
        label_LogOut.setFont(new java.awt.Font("Eras Demi ITC", 0, 14)); // NOI18N
        label_LogOut.setForeground(new java.awt.Color(255, 255, 255));
        label_LogOut.setText("LogOut");
        label_LogOut.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        label_LogOut.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                label_LogOutMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label_LogOut)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(label_LogOut)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(2, 22, 114));

        bAdd.setBackground(new java.awt.Color(255, 204, 0));
        bAdd.setFont(new java.awt.Font("Eras Demi ITC", 0, 18)); // NOI18N
        bAdd.setForeground(new java.awt.Color(255, 255, 255));
        bAdd.setText("Add");
        bAdd.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        bAdd.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAddActionPerformed(evt);
            }
        });

        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, message2List, jTable1);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${threadId}"));
        columnBinding.setColumnName("Thread Id");
        columnBinding.setColumnClass(Integer.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${message}"));
        columnBinding.setColumnName("Message");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${lastEdited}"));
        columnBinding.setColumnName("Last Edited");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${createBy}"));
        columnBinding.setColumnName("Create By");
        columnBinding.setColumnClass(String.class);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();

        jScrollPane1.setViewportView(jTable1);

        txtMessage.setColumns(20);
        txtMessage.setRows(5);
        jScrollPane3.setViewportView(txtMessage);

        bChatSelectWindow.setBackground(new java.awt.Color(255, 204, 0));
        bChatSelectWindow.setFont(new java.awt.Font("Eras Demi ITC", 0, 18)); // NOI18N
        bChatSelectWindow.setForeground(new java.awt.Color(255, 255, 255));
        bChatSelectWindow.setText("Chat Select Window");
        bChatSelectWindow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bChatSelectWindowActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 740, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 373, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55)
                        .addComponent(bAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bChatSelectWindow)))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bChatSelectWindow))
                        .addGap(59, 59, 59))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void label_LogOutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_label_LogOutMouseClicked
        // when logOut clicked
        Login login = new Login(); //create a new object of Login
        login.setVisible(true); // set visible true for the ChatSelectThread window
        login.pack();  // set the window size for the defualt
        login.setLocationRelativeTo(null);  // set a location in display
        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //close the current window
        this.dispose(); //component is displayable
    }//GEN-LAST:event_label_LogOutMouseClicked

    private void bAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAddActionPerformed
       // when click the add button it takes the pc current time and date
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MMM/yyyy__HH/mm/ss"); // date and time fomat
        LocalDateTime now = LocalDateTime.now(); // taking the current time
        String message = txtMessage.getText(); // take the message
        Client_Side.Client.addMessage(threadId, message, dtf.format(now), this.id); // have to ask
    }//GEN-LAST:event_bAddActionPerformed

    private void bChatSelectWindowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bChatSelectWindowActionPerformed
      // when click the button its open the chat delect window
        ChatSelectThread chatSelectThread = new ChatSelectThread(); //create a new object of ChatSelectThread
        chatSelectThread.setVisible(true); // set visible true for the ChatSelectThread window
        chatSelectThread.pack(); // set the window size for the defualt
        chatSelectThread.setLocationRelativeTo(null); // set a location in display
        chatSelectThread.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//close the current window
        this.dispose(); //component is displayable
    }//GEN-LAST:event_bChatSelectWindowActionPerformed

    public static void main(String args[]) {

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ChatEditThreadA().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAdd;
    private javax.swing.JButton bChatSelectWindow;
    private javax.persistence.EntityManager entityManager;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel label_LogOut;
    private java.util.List<Client_Side.Message2> message2List;
    private javax.persistence.Query message2Query;
    private java.util.List<Client_Side.Message> messageList;
    private java.util.List<Client_Side.Message> messageList1;
    private java.util.List<Client_Side.Message> messageList2;
    private javax.persistence.Query messageQuery;
    private javax.persistence.Query messageQuery1;
    private javax.persistence.Query messageQuery2;
    private javax.swing.JTextArea txtMessage;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
