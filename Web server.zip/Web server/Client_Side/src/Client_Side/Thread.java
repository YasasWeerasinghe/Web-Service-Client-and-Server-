/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client_Side;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Yasas Weerasingh
 */
@Entity
@Table(name = "thread", catalog = "iitcsacw", schema = "")
@NamedQueries({
    @NamedQuery(name = "Thread.findAll", query = "SELECT t FROM Thread t")
    , @NamedQuery(name = "Thread.findByTitle", query = "SELECT t FROM Thread t WHERE t.title = :title")
    , @NamedQuery(name = "Thread.findByCreateby", query = "SELECT t FROM Thread t WHERE t.createby = :createby")
    , @NamedQuery(name = "Thread.findByTime", query = "SELECT t FROM Thread t WHERE t.time = :time")})
public class Thread implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "title")
    private String title;
    @Id
    @Basic(optional = false)
    @Column(name = "createby")
    private String createby;
    @Basic(optional = false)
    @Column(name = "time")
    private String time;

    public Thread() {
    }

    public Thread(String createby) {
        this.createby = createby;
    }

    public Thread(String createby, String title, String time) {
        this.createby = createby;
        this.title = title;
        this.time = time;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        String oldTitle = this.title;
        this.title = title;
        changeSupport.firePropertyChange("title", oldTitle, title);
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        String oldCreateby = this.createby;
        this.createby = createby;
        changeSupport.firePropertyChange("createby", oldCreateby, createby);
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        String oldTime = this.time;
        this.time = time;
        changeSupport.firePropertyChange("time", oldTime, time);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (createby != null ? createby.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Thread)) {
            return false;
        }
        Thread other = (Thread) object;
        if ((this.createby == null && other.createby != null) || (this.createby != null && !this.createby.equals(other.createby))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Client_Side.Thread[ createby=" + createby + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
