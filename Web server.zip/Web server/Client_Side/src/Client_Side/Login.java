package Client_Side;
import java.sql.*;
import javax.swing.*;
/**
 *
 * @author Yasas Weerasingh
 */
public class Login extends javax.swing.JFrame {
   
    public Login() {
        initComponents();
               
        setExtendedState(JFrame.MAXIMIZED_HORIZ); //disable the window resize
        setVisible(true); // the window visible is true
        setResizable(false); // the window can't resize
    }

       @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        txtLoginID = new javax.swing.JTextField();
        txtPassword = new javax.swing.JPasswordField();
        bLogin = new javax.swing.JToggleButton();
        label_Register = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 162, 0));
        jPanel1.setPreferredSize(new java.awt.Dimension(120, 50));

        jLabel3.setFont(new java.awt.Font("Eras Bold ITC", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("DIYO Chat Login");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addContainerGap(194, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(2, 22, 114));
        jPanel2.setPreferredSize(new java.awt.Dimension(352, 344));

        txtLoginID.setBackground(new java.awt.Color(2, 22, 114));
        txtLoginID.setFont(new java.awt.Font("Eras Demi ITC", 0, 18)); // NOI18N
        txtLoginID.setForeground(new java.awt.Color(255, 255, 255));
        txtLoginID.setBorder(null);
        txtLoginID.setCaretColor(new java.awt.Color(255, 255, 255));
        txtLoginID.setPreferredSize(new java.awt.Dimension(352, 28));

        txtPassword.setBackground(new java.awt.Color(2, 22, 114));
        txtPassword.setFont(new java.awt.Font("Eras Demi ITC", 0, 18)); // NOI18N
        txtPassword.setForeground(new java.awt.Color(255, 255, 255));
        txtPassword.setBorder(null);
        txtPassword.setCaretColor(new java.awt.Color(255, 255, 255));
        txtPassword.setPreferredSize(new java.awt.Dimension(332, 28));

        bLogin.setBackground(new java.awt.Color(255, 224, 0));
        bLogin.setFont(new java.awt.Font("Eras Demi ITC", 0, 18)); // NOI18N
        bLogin.setForeground(new java.awt.Color(255, 255, 255));
        bLogin.setText("Login");
        bLogin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bLoginActionPerformed(evt);
            }
        });

        label_Register.setFont(new java.awt.Font("Eras Demi ITC", 0, 18)); // NOI18N
        label_Register.setForeground(new java.awt.Color(255, 255, 255));
        label_Register.setText("Register");
        label_Register.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        label_Register.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                label_RegisterMouseClicked(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Eras Demi ITC", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Login ID");

        jSeparator2.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Eras Demi ITC", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Password");

        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(bLogin)
                        .addGap(70, 70, 70)
                        .addComponent(label_Register))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel1)
                            .addComponent(jSeparator2)
                            .addComponent(txtLoginID, javax.swing.GroupLayout.DEFAULT_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jSeparator1)
                            .addComponent(jLabel2)
                            .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(51, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(9, 9, 9)
                .addComponent(txtLoginID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jLabel2)
                .addGap(8, 8, 8)
                .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bLogin)
                    .addComponent(label_Register))
                .addGap(37, 37, 37))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 413, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 413, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 355, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bLoginActionPerformed
       // when login button click its check all fiels are empty or not
        if(txtLoginID.getText().isEmpty()||txtPassword.getText().isEmpty()){
            // show error msg when fields are not filed
            JOptionPane.showMessageDialog(null,"Login fields are not filed","WARNING",JOptionPane.WARNING_MESSAGE);
        }else{

        try{
                //  connection of the GUI and the Web Service
             boolean login = Client_Side.Client.login(txtPassword.getText(), txtLoginID.getText());
            if(login){
                // open the ChatSelectThread java class (window) and close the current window
                ChatSelectThread chatSelectWindow = new ChatSelectThread(txtLoginID.getText()); //create a new object of ChatSelectThread
                chatSelectWindow.setVisible(true);  // set visible true for the ChatSelectThread window
                chatSelectWindow.pack();  // set the window size for the defualt
                chatSelectWindow.setLocationRelativeTo(null); // set the window size for the defualt
                chatSelectWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// close the current window
                this.dispose(); //window is terminate
            }else{
                // error msg when the filed content is not macth with the DB
                JOptionPane.showMessageDialog(null,"Invalide LoginID or Password","WARNING",JOptionPane.WARNING_MESSAGE);
                // clear the fields
                 txtLoginID.setText("");
                 txtPassword.setText("");
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
       
        }
    }//GEN-LAST:event_bLoginActionPerformed

    private void label_RegisterMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_label_RegisterMouseClicked
       // when click the registration text its open register window 
       Registration regForm = new Registration(); //create a new object of Registration
       regForm.setVisible(true);  // set visible true for the login window
       regForm.pack();  // set the window size for the defualt
       regForm.setLocationRelativeTo(null); // set the window size for the defualt
       regForm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // close the current window
       this.dispose(); //window is terminate
    }//GEN-LAST:event_label_RegisterMouseClicked

   
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton bLogin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel label_Register;
    private javax.swing.JTextField txtLoginID;
    private javax.swing.JPasswordField txtPassword;
    // End of variables declaration//GEN-END:variables
}
