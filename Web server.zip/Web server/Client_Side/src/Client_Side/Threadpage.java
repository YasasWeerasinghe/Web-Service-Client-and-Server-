/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client_Side;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Yasas Weerasingh
 */
@Entity
@Table(name = "threadpage", catalog = "iitcsacw", schema = "")
@NamedQueries({
    @NamedQuery(name = "Threadpage.findAll", query = "SELECT t FROM Threadpage t")
    , @NamedQuery(name = "Threadpage.findByThreadNo", query = "SELECT t FROM Threadpage t WHERE t.threadNo = :threadNo")
    , @NamedQuery(name = "Threadpage.findByTiitle", query = "SELECT t FROM Threadpage t WHERE t.tiitle = :tiitle")
    , @NamedQuery(name = "Threadpage.findByCreateby", query = "SELECT t FROM Threadpage t WHERE t.createby = :createby")
    , @NamedQuery(name = "Threadpage.findByTime", query = "SELECT t FROM Threadpage t WHERE t.time = :time")})
public class Threadpage implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "threadNo")
    private Integer threadNo;
    @Column(name = "tiitle")
    private String tiitle;
    @Column(name = "createby")
    private String createby;
    @Column(name = "time")
    private String time;

    public Threadpage() {
    }

    public Threadpage(Integer threadNo) {
        this.threadNo = threadNo;
    }

    public Integer getThreadNo() {
        return threadNo;
    }

    public void setThreadNo(Integer threadNo) {
        Integer oldThreadNo = this.threadNo;
        this.threadNo = threadNo;
        changeSupport.firePropertyChange("threadNo", oldThreadNo, threadNo);
    }

    public String getTiitle() {
        return tiitle;
    }

    public void setTiitle(String tiitle) {
        String oldTiitle = this.tiitle;
        this.tiitle = tiitle;
        changeSupport.firePropertyChange("tiitle", oldTiitle, tiitle);
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        String oldCreateby = this.createby;
        this.createby = createby;
        changeSupport.firePropertyChange("createby", oldCreateby, createby);
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        String oldTime = this.time;
        this.time = time;
        changeSupport.firePropertyChange("time", oldTime, time);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (threadNo != null ? threadNo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Threadpage)) {
            return false;
        }
        Threadpage other = (Threadpage) object;
        if ((this.threadNo == null && other.threadNo != null) || (this.threadNo != null && !this.threadNo.equals(other.threadNo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Client_Side.Threadpage[ threadNo=" + threadNo + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
