/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client_Side;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Yasas Weerasingh
 */
@Entity
@Table(name = "message2", catalog = "iitcsacw", schema = "")
@NamedQueries({
    @NamedQuery(name = "Message2.findAll", query = "SELECT m FROM Message2 m")
    , @NamedQuery(name = "Message2.findByMessage", query = "SELECT m FROM Message2 m WHERE m.message = :message")
    , @NamedQuery(name = "Message2.findByLastEdited", query = "SELECT m FROM Message2 m WHERE m.lastEdited = :lastEdited")
    , @NamedQuery(name = "Message2.findByCreateBy", query = "SELECT m FROM Message2 m WHERE m.createBy = :createBy")
    , @NamedQuery(name = "Message2.findByThreadId", query = "SELECT m FROM Message2 m WHERE m.threadId = :threadId")})
public class Message2 implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "message")
    private String message;
    @Id
    @Basic(optional = false)
    @Column(name = "lastEdited")
    private String lastEdited;
    @Basic(optional = false)
    @Column(name = "createBy")
    private String createBy;
    @Column(name = "threadId")
    private Integer threadId;

    public Message2() {
    }

    public Message2(String lastEdited) {
        this.lastEdited = lastEdited;
    }

    public Message2(String lastEdited, String message, String createBy) {
        this.lastEdited = lastEdited;
        this.message = message;
        this.createBy = createBy;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        String oldMessage = this.message;
        this.message = message;
        changeSupport.firePropertyChange("message", oldMessage, message);
    }

    public String getLastEdited() {
        return lastEdited;
    }

    public void setLastEdited(String lastEdited) {
        String oldLastEdited = this.lastEdited;
        this.lastEdited = lastEdited;
        changeSupport.firePropertyChange("lastEdited", oldLastEdited, lastEdited);
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        String oldCreateBy = this.createBy;
        this.createBy = createBy;
        changeSupport.firePropertyChange("createBy", oldCreateBy, createBy);
    }

    public Integer getThreadId() {
        return threadId;
    }

    public void setThreadId(Integer threadId) {
        Integer oldThreadId = this.threadId;
        this.threadId = threadId;
        changeSupport.firePropertyChange("threadId", oldThreadId, threadId);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (lastEdited != null ? lastEdited.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Message2)) {
            return false;
        }
        Message2 other = (Message2) object;
        if ((this.lastEdited == null && other.lastEdited != null) || (this.lastEdited != null && !this.lastEdited.equals(other.lastEdited))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Client_Side.Message2[ lastEdited=" + lastEdited + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
