package SeverThread;

import Sever.Sever;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Yasas Weerasingh
 */
@WebService(serviceName = "SeverThread")
public class SeverThread {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "chatAddThread")
    public void chatAddThread(@WebParam(name = "title") String title,@WebParam(name = "createBy") String createby,@WebParam(name = "time") String time) {
        try {
            Class.forName("com.mysql.jdbc.Driver"); //db driver
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Sever.class.getName()).log(Level.SEVERE, null, ex);
        }
            try {
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/iitcsacw","root","");// database path
                
                 // chatThread db table sql query // inserting data to the table
        String sql = "Insert into threadpage (tiitle,createby,time) values ('"+title+"','"+createby+"','"+time+"')";
        Statement stat =(Statement) conn.prepareStatement(sql); // send sql statment to the database
        stat.executeUpdate(sql); //close the database connection to void tying up database resources
              
            } catch (SQLException ex) {
                Logger.getLogger(Sever.class.getName()).log(Level.SEVERE, null, ex);
            }            
             
    }
    
    @WebMethod(operationName = "add_Message")
          public void add_Message(@WebParam(name = "message") String message,@WebParam(name = "last_Edited") String last_Edited,@WebParam(name = "createBy") String createBy,@WebParam(name = "threadID") int threadID) {
       //  public void add_Message(@WebParam(name = "threadID") int threadID,@WebParam(name = "message") String message,@WebParam(name = "last_Edited") String last_Edited,@WebParam(name = "createBy") String createBy) {
        try {
            Class.forName("com.mysql.jdbc.Driver"); // db driver
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Sever.class.getName()).log(Level.SEVERE, null, ex);
        }
            try {
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/iitcsacw","root","");  // database path
                
                 // addMessage db table sql query // inserting data to the table
        String sql = "Insert into message2 (message,lastEdited,createBy,threadId) values ('"+message+"','"+last_Edited+"','"+createBy+"',(SELECT threadpage.threadNo FROM threadpage WHERE threadpage.threadNo = "+threadID+"))";
        Statement stat =(Statement) conn.prepareStatement(sql); // send sql statment to the database
        stat.executeUpdate(sql); //close the database connection to void tying up database resources
              
            } catch (SQLException ex) {
                Logger.getLogger(Sever.class.getName()).log(Level.SEVERE, null, ex);
            }            
             
    }
}
